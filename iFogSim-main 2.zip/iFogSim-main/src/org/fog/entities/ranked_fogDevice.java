package org.fog.entities;

public class ranked_fogDevice {
    private FogDevice fogdevice;
    private double resource_score;
    ranked_fogDevice(FogDevice fogdevice, double resource_score) {
        this.fogdevice = fogdevice;
        this.resource_score = resource_score;
    }
    public void setFogdevice(FogDevice fogdevice) {
        this.fogdevice = fogdevice;
    }
    public FogDevice getFogdevice() {
        return fogdevice;
    }
    public void setResource_score(double resource_score) {
        this.resource_score = resource_score;
    }
    public double getResource_score() {
        return resource_score;
    }
}

