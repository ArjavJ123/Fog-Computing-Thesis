package org.fog.entities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Collections;
import java.util.Comparator;
import org.apache.commons.math3.util.Pair;
import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmAllocationPolicy;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.SimEntity;
import org.cloudbus.cloudsim.core.SimEvent;
import org.cloudbus.cloudsim.power.PowerDatacenter;
import org.cloudbus.cloudsim.power.PowerHost;
import org.cloudbus.cloudsim.power.models.PowerModel;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;
import org.cloudbus.cloudsim.sdn.overbooking.BwProvisionerOverbooking;
import org.cloudbus.cloudsim.sdn.overbooking.PeProvisionerOverbooking;
import org.fog.application.AppEdge;
import org.fog.application.AppLoop;
import org.fog.application.AppModule;
import org.fog.application.Application;
import org.fog.mobilitydata.Clustering;
import org.fog.policy.AppModuleAllocationPolicy;
import org.fog.scheduler.StreamOperatorScheduler;
import org.fog.utils.*;
import org.json.simple.JSONObject;

public class FogServer extends SimEntity {
    private final int gatewaydeviceId;
    private final List<FogDevice> fogDevices = new ArrayList<FogDevice>();
    private static final List<ranked_fogDevice>LOR = new ArrayList<ranked_fogDevice>();
    @Override
    public void startEntity() {

        send(gatewaydeviceId, CloudSim.getMinTimeBetweenEvents(), FogEvents.SERVER_JOINED);
    }

    @Override
    public void processEvent(SimEvent ev) {
        switch (ev.getTag()) {
            case FogEvents.SERVER_JOINED:
                createLOR(fogDevices);
            case FogEvents.ADD_QUEUE:
                Tuple tuple = (Tuple) ev.getData();
                assignTask(tuple);
        }

    }

    public  FogServer(String name) {
        super(name);
        gatewaydeviceId = FogUtils.generateEntityId();

    }

    public static void createLOR(List<FogDevice> assignResList) {
        /*int Pm = getProcessingPower(a);
        int Bm = getTotalBandwidth(a);
        for(int i =0; i < assignResList.size(); i++) {
            if (getProcessingPower(assignResList[i]) < Pm) {
                Pm = getProcessingPower(assignResList[i]);
            }
            if (getTotalBandwidth(assignResList[i]) < Bm) {
                Bm = getTotalBandwidth(assignResList[i]);
            }
        }*/
        double Tr;
        double Wp,Wl,Wb;
        Wp = 1/3;
        Wb = 1/3;
        Wl = 1/3;
        for (int i=0; i < assignResList.size(); i++) {
            Tr = Wp* assignResList.get(i).getHost().getAvailableMips() + Wb* assignResList.get(i).getDownlinkBandwidth()+ Wl* assignResList.get(i).getUplinkLatency();
            ranked_fogDevice temp = new ranked_fogDevice(assignResList.get(i), Tr);
            LOR.add(temp);
        }
        Collections.sort(LOR, Comparator.comparingDouble(ranked_fogDevice::getResource_score).reversed());
    }
    public static void UpdateLOR(FogDevice fogDevice) {
        double Tr = 0;
        double Wp, Wl, Wb;
        Wp = 1 / 3;
        Wb = 1 / 3;
        Wl = 1 / 3;
        int place = 0;
        for(int i=0; i<LOR.size(); i++) {
            if(fogDevice.getId() == LOR.get(i).getFogdevice().getId()) {
                Tr = Wp * fogDevice.getHost().getAvailableMips() + Wb * fogDevice.getDownlinkBandwidth() + Wl * fogDevice.getUplinkLatency();
                LOR.get(i).setResource_score(Tr);
                place = i;
            }
        }
        for(int i=place; i<LOR.size(); i++) {
            if(Tr< LOR.get(i).getResource_score()) {
                ranked_fogDevice Temp;
                Temp = LOR.get(place);
                LOR.set(place, LOR.get(i));
                LOR.set(i, Temp);
                place = i;
            }
        }
    }
    public void assignTask(Tuple tuple) {
        int priority = tuple.getPriority();
        int c = 0;
        FogDevice fogDevice;
        if (priority == 0) {
            for (ranked_fogDevice rankedFogDevice : LOR) {
                fogDevice = rankedFogDevice.getFogdevice();
                if (tuple.getCloudletLength() <= fogDevice.getHost().getAvailableMips() && fogDevice.getDownlinkBandwidth() >= tuple.getCloudletOutputSize()) {
                    send(fogDevice.getId(), fogDevice.getUplinkLatency(), FogEvents.TUPLE_ARRIVAL, tuple);
                    c++;
                    UpdateLOR(fogDevice);
                    break;
                }

                /* else {
                    //preempt logic
                } */
            }
        } else if (priority == 2) {
            for (int i = LOR.size() - 1; i >= 0; i--) {
                fogDevice = LOR.get(i).getFogdevice();
                if (tuple.getCloudletLength() <= fogDevice.getHost().getAvailableMips() && fogDevice.getDownlinkBandwidth() >= tuple.getCloudletOutputSize()) {
                    send(fogDevice.getId(), fogDevice.getUplinkLatency(), FogEvents.TUPLE_ARRIVAL, tuple);
                    c++;
                    UpdateLOR(fogDevice);
                    break;
                }
            }

        } else if (priority == 1) {
            for (int i = LOR.size() / 2; i >= 0; i--) {
                fogDevice = LOR.get(i).getFogdevice();
                if (tuple.getCloudletLength() <= fogDevice.getHost().getAvailableMips() && fogDevice.getDownlinkBandwidth() >= tuple.getCloudletOutputSize()) {
                    send(fogDevice.getId(), fogDevice.getUplinkLatency(), FogEvents.TUPLE_ARRIVAL, tuple);
                    c++;
                    UpdateLOR(fogDevice);
                    break;
                }
            }
        }
        if (c == 0) {
            if (tuple.getPriority() == 2) {
                send("cloud", 0, FogEvents.TUPLE_ARRIVAL, tuple);
            } else {
                for (ranked_fogDevice rankedFogDevice : LOR) {
                    fogDevice = rankedFogDevice.getFogdevice();
                    if (fogDevice.getCurrentTuple().getPriority() == 2) {
                        fogDevice.preempt();
                        send(fogDevice.getId(), fogDevice.getUplinkLatency(), FogEvents.TUPLE_ARRIVAL, tuple);
                        c++;
                        UpdateLOR(fogDevice);
                        break;
                    }
                }
            }
        }
        if(c==0 ) {
            if (tuple.getPriority() == 0) {
                for (ranked_fogDevice rankedFogDevice : LOR) {
                    fogDevice = rankedFogDevice.getFogdevice();
                    if (fogDevice.getCurrentTuple().getPriority() == 1) {
                        fogDevice.preempt();
                        send(fogDevice.getId(), fogDevice.getUplinkLatency(), FogEvents.TUPLE_ARRIVAL, tuple);
                        ;
                        UpdateLOR(fogDevice);
                        break;
                    }
                }
            }
            else if (tuple.getPriority() == 1) {
                send("cloud", 0, FogEvents.TUPLE_ARRIVAL, tuple);
            }
        }
    }


    @Override
    public void shutdownEntity() {

    }
    public void addFogDevice(FogDevice fogDevice) {
        fogDevices.add(fogDevice);
    }
}